
module.exports = require('./lib/oracle');
